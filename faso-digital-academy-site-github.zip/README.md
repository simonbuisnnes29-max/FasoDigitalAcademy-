# Faso Digital Academy — Site web

Site vitrine responsive de **Faso Digital Academy**, prêt à être publié sur GitHub Pages.

## Fichiers
- `index.html` — page principale
- `styles.css` — design responsive
- `script.js` — menu mobile et année automatique
- `assets/logo.png` — logo fourni
- `assets/systemes-exploitation.png` — infographie sur les systèmes d’exploitation

## Publier sur GitHub Pages
1. Crée un nouveau dépôt GitHub, par exemple `faso-digital-academy`.
2. Envoie tous les fichiers de ce dossier à la racine du dépôt.
3. Dans GitHub : **Settings → Pages**.
4. Choisis **Deploy from a branch**, puis la branche `main` et le dossier `/root`.
5. Enregistre : GitHub générera l'adresse publique du site.

Le site est statique : aucun serveur ou base de données n'est nécessaire pour cette première version.
